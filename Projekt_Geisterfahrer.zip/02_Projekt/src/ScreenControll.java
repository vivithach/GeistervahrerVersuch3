import processing.core.PApplet;

public class ScreenControll {

    private PApplet app;

    public ScreenControll(PApplet app) {
        this.app = app;
    }

    void initScreen() {
        app.background(236, 240, 241);
        app.textAlign(app.CENTER);
        app.fill(52, 73, 94);
        app.textSize(70);
        app.text("Auto-Spiel", app.width/2, app.height/2);
        app.textSize(15);
        app.text("Click to start", app.width/2, app.height-30);
    }
    void gameOverScreen() {
        app.background(44, 62, 80);
        app.textAlign(app.CENTER);
        app.fill(236, 240, 241);
        app.textSize(12);
        app.text("Your Score", app.width/2, app.height/2 - 120);
        app.textSize(130);
        app.textSize(15);
        app.text("Click to Restart", app.width/2, app.height-30);
    }
}
