public enum GameScreen {
    START_SCREEN,
    GAME_SCREEN,
    GAMEOVER_SCREEN
}
